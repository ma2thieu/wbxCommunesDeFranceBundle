-- phpMyAdmin SQL Dump
-- version 3.3.7deb7
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Apr 29, 2013 at 04:21 PM
-- Server version: 5.1.66
-- PHP Version: 5.3.3-7+squeeze15

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

INSERT INTO `Region` (`nom`, `code`) VALUES
('Guadeloupe', '01'),
('Martinique', '02'),
('Guyane', '03'),
('La Réunion', '04'),
('Mayotte', '06'),
('Île-de-France', '11'),
('Champagne-Ardenne', '21'),
('Picardie', '22'),
('Haute-Normandie', '23'),
('Centre', '24'),
('Basse-Normandie', '25'),
('Bourgogne', '26'),
('Nord-Pas-de-Calais', '31'),
('Lorraine', '41'),
('Alsace', '42'),
('Franche-Comté', '43'),
('Pays de la Loire', '52'),
('Bretagne', '53'),
('Poitou-Charentes', '54'),
('Aquitaine', '72'),
('Midi-Pyrénées', '73'),
('Limousin', '74'),
('Rhône-Alpes', '82'),
('Auvergne', '83'),
('Languedoc-Roussillon', '91'),
('Provence-Alpes-Côte d''Azur', '93'),
('Corse', '94');
